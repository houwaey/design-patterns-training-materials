package com.patterns.decorator.solution;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CompressedCloudStream implements Stream {
    private Stream stream;

    @Override
    public void write(String data) {
        String compressed = compress(data);
        stream.write(compressed);
    }

    private String compress(String data) {
        return data.substring(0, 5);
    }
}
