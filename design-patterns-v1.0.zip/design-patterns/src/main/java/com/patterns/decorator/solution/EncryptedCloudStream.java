package com.patterns.decorator.solution;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class EncryptedCloudStream implements Stream {
    private Stream stream;

    @Override
    public void write(String data) {
        String encrypted = encrypt(data);
        stream.write(encrypted);
    }

    private String encrypt(String data) {
        return "!@##%&%&()*)*&$@%&";
    }
}
