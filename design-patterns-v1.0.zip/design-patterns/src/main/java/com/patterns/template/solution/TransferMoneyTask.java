package com.patterns.template.solution;

import com.patterns.template.problem.AuditTrail;

public class TransferMoneyTask extends Task {
    public TransferMoneyTask(AuditTrail auditTrail) {
        super(auditTrail);
    }

    @Override
    public void doExecute() {
        System.out.println("Transfer Money");
    }
}
