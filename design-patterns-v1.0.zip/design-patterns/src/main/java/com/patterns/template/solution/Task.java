package com.patterns.template.solution;

import com.patterns.template.problem.AuditTrail;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public abstract class Task {
    private AuditTrail auditTrail;

    public void execute() {
        auditTrail.record();

        doExecute();
    }

    public abstract void doExecute();
}
