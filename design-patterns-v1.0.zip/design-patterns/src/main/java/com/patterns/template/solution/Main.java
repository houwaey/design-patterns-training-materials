package com.patterns.template.solution;

import com.patterns.template.problem.AuditTrail;

public class Main {
    public static void main(String[] args) {
        AuditTrail auditTrail = new AuditTrail();

        Task task = new TransferMoneyTask(auditTrail);
        task.execute();

        task = new GenerateReportTask(auditTrail);
        task.execute();
    }
}
