package com.patterns.template.problem;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class GenerateReportTask {
    private AuditTrail auditTrail;

    public void execute() {
        auditTrail.record();

        System.out.println("Generate Report");
    }
}
