package com.patterns.template.problem;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class TransferMoneyTask {
    private AuditTrail auditTrail;

    public void execute() {
        auditTrail.record();

        System.out.println("Transfer Money");
    }
}
