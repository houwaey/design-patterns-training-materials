package com.patterns.template.solution;

import com.patterns.template.problem.AuditTrail;

public class GenerateReportTask extends Task {
    public GenerateReportTask(AuditTrail auditTrail) {
        super(auditTrail);
    }

    @Override
    public void doExecute() {
        System.out.println("Generate Report");
    }
}
