package com.patterns.state.solution;

public class SelectionTool implements Tool {
    @Override
    public void mouseUp() {
        System.out.println("MouseUp: Change Mouse Pointer to Selection icon");
    }

    @Override
    public void mouseDown() {
        System.out.println("MouseDown: Draw dashed rectangle");
    }
}
