package com.patterns.state.solution;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Canvas {
    private Tool currentTool;

    public void mouseUp() {
        currentTool.mouseUp();
    }

    public void mouseDown() {
        currentTool.mouseDown();
    }
}
