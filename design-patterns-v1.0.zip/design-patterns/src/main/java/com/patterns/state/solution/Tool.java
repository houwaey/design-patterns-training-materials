package com.patterns.state.solution;

public interface Tool {
    void mouseUp();
    void mouseDown();
}
