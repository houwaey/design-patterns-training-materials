package com.patterns.state.problem;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Canvas {
    private ToolType currentTool;

    public void mouseUp() {
        if (currentTool == ToolType.SELECTION) {
            System.out.println("MouseUp: Change Mouse Pointer to Selection icon");
        } else if (currentTool == ToolType.BRUSH) {
            System.out.println("MouseUp: Change Mouse Pointer to Brush icon");
        } else if (currentTool == ToolType.ERASER) {
            System.out.println("MouseUp: Change Mouse Pointer to Eraser icon");
        }
    }

    public void mouseDown() {
        if (currentTool == ToolType.SELECTION) {
            System.out.println("MouseDown: Draw dashed rectangle");
        } else if (currentTool == ToolType.BRUSH) {
            System.out.println("MouseDown: Draw a line");
        } else if (currentTool == ToolType.ERASER) {
            System.out.println("MouseDown: Erase something");
        }
    }
}
