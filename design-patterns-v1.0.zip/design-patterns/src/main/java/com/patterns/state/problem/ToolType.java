package com.patterns.state.problem;

public enum ToolType {
    SELECTION,
    BRUSH,
    ERASER
}
