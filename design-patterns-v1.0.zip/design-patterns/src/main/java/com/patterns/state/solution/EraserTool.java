package com.patterns.state.solution;

public class EraserTool implements Tool {
    @Override
    public void mouseUp() {
        System.out.println("MouseUp: Change Mouse Pointer to Eraser icon");
    }

    @Override
    public void mouseDown() {
        System.out.println("MouseDown: Erase something");
    }
}
