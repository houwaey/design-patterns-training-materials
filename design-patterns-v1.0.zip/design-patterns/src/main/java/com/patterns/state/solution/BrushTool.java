package com.patterns.state.solution;

public class BrushTool implements Tool {
    @Override
    public void mouseUp() {
        System.out.println("MouseUp: Change Mouse Pointer to Brush icon");
    }

    @Override
    public void mouseDown() {
        System.out.println("MouseDown: Draw a line");
    }
}
