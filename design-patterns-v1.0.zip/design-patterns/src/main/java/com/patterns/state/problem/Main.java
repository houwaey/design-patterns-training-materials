package com.patterns.state.problem;

public class Main {
    public static void main(String[] args) {
        Canvas canvas = new Canvas();
        canvas.setCurrentTool(ToolType.ERASER);
        canvas.mouseUp();
        canvas.mouseDown();
    }
}
