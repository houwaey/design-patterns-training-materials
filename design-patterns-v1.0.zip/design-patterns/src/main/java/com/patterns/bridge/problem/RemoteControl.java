package com.patterns.bridge.problem;

public abstract class RemoteControl {
    public abstract void turnOn();
    public abstract void turnOff();
}
