package com.patterns.bridge.solution;

public interface Device {
    void turnOn();
    void turnOff();
    void setChannel(int number);
}
