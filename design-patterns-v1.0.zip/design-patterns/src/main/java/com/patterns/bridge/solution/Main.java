package com.patterns.bridge.solution;

public class Main {
    public static void main(String[] args) {
        RemoteControl remoteControl = new RemoteControl(new SonyTV());
        remoteControl.turnOn();
        remoteControl.turnOff();
        System.out.println();

        AdvancedRemoteControl advancedRemoteControl = new AdvancedRemoteControl(new SonyTV());
        advancedRemoteControl.turnOn();
        advancedRemoteControl.setChannel(100);
        advancedRemoteControl.turnOff();
    }
}
