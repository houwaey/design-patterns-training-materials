package com.patterns.adapter.problem;

import com.patterns.adapter.applefilters.Caramel;
import com.patterns.adapter.common.Image;

public class Main {
    public static void main(String[] args) {
        ImageView imageView = new ImageView(new Image());
        imageView.apply(new VividFilter());
//        imageView.apply(new Caramel()); // cannot be :(
    }
}
