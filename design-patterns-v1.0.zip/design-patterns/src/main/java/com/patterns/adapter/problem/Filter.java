package com.patterns.adapter.problem;

import com.patterns.adapter.common.Image;

public interface Filter {
    void apply(Image image);
}
