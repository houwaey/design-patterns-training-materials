package com.patterns.adapter.solution;

import com.patterns.adapter.applefilters.Caramel;
import com.patterns.adapter.common.Image;
import lombok.AllArgsConstructor;

// Option 1
@AllArgsConstructor
public class CaramelFilter implements Filter {
    private Caramel caramel;

    @Override
    public void apply(Image image) {
        caramel.init();
        caramel.render(image);
    }
}
