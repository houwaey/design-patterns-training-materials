package com.patterns.adapter.solution;

import com.patterns.adapter.common.Image;

public interface Filter {
    void apply(Image image);
}
