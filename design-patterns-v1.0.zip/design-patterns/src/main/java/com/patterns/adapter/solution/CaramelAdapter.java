package com.patterns.adapter.solution;

import com.patterns.adapter.common.Image;
import com.patterns.adapter.applefilters.Caramel;

// Option 2
public class CaramelAdapter extends Caramel implements Filter {
    @Override
    public void apply(Image image) {
        init();
        render(image);
    }
}
