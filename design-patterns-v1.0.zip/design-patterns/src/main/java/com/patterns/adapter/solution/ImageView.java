package com.patterns.adapter.solution;

import com.patterns.adapter.common.Image;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ImageView {
    private Image image;

    public void apply(Filter filter) {
        filter.apply(image);
    }
}
