package com.patterns.strategy.solution;

public class Main {
    public static void main(String[] args) {
        ImageStorage imageStorage = new ImageStorage();
        imageStorage.store("File1", new PngCompressor(), new HighContrastFilter());
    }
}
