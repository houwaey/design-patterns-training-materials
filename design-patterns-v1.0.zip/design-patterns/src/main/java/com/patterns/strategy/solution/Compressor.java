package com.patterns.strategy.solution;

public interface Compressor {
    void compress(String fileName);
}
