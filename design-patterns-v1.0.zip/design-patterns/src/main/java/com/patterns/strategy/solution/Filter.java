package com.patterns.strategy.solution;

public interface Filter {
    void apply(String fileName);
}
