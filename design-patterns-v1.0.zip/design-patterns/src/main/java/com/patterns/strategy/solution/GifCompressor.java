package com.patterns.strategy.solution;

public class GifCompressor implements Compressor {
    @Override
    public void compress(String fileName) {
        System.out.println("Compressing using GIF");
    }
}
