package com.patterns.strategy.solution;

public class HighContrastFilter implements Filter {
    @Override
    public void apply(String fileName) {
        System.out.println("Applying High Contrast filter");
    }
}
